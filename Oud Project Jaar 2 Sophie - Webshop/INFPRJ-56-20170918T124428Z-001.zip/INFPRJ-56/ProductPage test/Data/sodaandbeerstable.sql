﻿-- Table: public.sodaandbeers

-- DROP TABLE public.sodaandbeers;

CREATE TABLE public.sodaandbeers
(
  id integer NOT NULL,
  "Brand" character(80),
  "Title" character(80),
  "Version" character(80),
  "Price" integer NOT NULL,
  "Description" character(80),
  "Color" character(80),
  "Volume" character(80),
  "Image" uuid,
  "Category" character(80),
  CONSTRAINT pg_id PRIMARY KEY (id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE public.sodaandbeers
  OWNER TO postgres;
