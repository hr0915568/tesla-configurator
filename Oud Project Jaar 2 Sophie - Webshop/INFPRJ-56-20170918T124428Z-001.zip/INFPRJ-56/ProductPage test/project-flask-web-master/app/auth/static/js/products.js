$(function(){
	$( window).load(function(){
		$.ajax({
			url: '/api/test',
			contentType: "application/json",

			type: 'GET',
			success: function(response){
				console.log(response);
			},
			error: function(error){
				console.log(error);
			}
		});

	    })

	});


function generateView(product){
    var view = "<div ID='0' class = 'productcard card-container'>" +
    "<div class = 'headercontainer'>" +
        "<h1 class='productsname'>" + product['title'] + "</h1>" +
    "</div>" +
    "<div class='productinfocontainer'> " +
        "<div class='productsimage'>"  + product['img'] + "</div>" +
        "<div class='productprice'>" + product['price'] + "</div>" +
        "<div class='viewmore'> <button class='btn btn-primary' type='submit'>View more</button> </div>" +
    "</div>" +
    "</div>"
    return view
}




function createProductDivWithInfo() {


    $.getJSON( "/api/test", function( data ) {

      $.each( data, function( index, product ) {
         var productview = generateView(product);

          $( productview ).appendTo( ".productpage" );
      });
    });

}

createProductDivWithInfo();


