$(function(){
	$('button').click(function(){
		
		var first_name = $('#txt-first-name').val();
		var middle_name = $('#txt-middle-name').val();
		var last_name = $('#txt-last-name').val();
		var username = $('#txt-username').val();
		var email = $('#txt-email').val();
		// var date = $('#option-date').val();
		var password = $('#txt-password').val();

		$.ajax({
			url: '/api/user',
			contentType: "application/json",
			data: JSON.stringify({
				first_name: first_name,
				middle_name : middle_name,
				last_name : last_name,
				username : username,
				email : email,
				password : password
			}),
			type: 'POST',
			success: function(response){
				console.log(response);
			},
			error: function(error){
				document.write(fir)
				console.log(error);
			}
		});
	});
});