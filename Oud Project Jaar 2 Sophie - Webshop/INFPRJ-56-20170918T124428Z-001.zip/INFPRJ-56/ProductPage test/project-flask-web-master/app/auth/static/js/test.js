$(function(){
	$( window).load(function(){
		$.ajax({
			url: '/api/test',
			contentType: "application/json",

			type: 'GET',
			success: function(response){
				console.log(response);
			},
			error: function(error){
				console.log(error);
			}
		});

	    })

	});



$.getJSON( "/api/test", function( data ) {
  var items = [];
  var data = data[0];
  $.each( data, function( key, val ) {
      if (key == 'title') {
          items.push( val );
      }
  });
  $( "<h1/>", {
    "class": "productname",
    html: items.join( "" )
  }).appendTo( ".productname" );
});

$.getJSON( "/api/test", function( data ) {
  var items = [];
  var data = data[0];
  $.each( data, function( key, val ) {

      if (key == "img"){
          items.push( val );
      }
  });
  $( "<h2/>", {
    "class": "productimage",
    html: items.join( "" )
  }).appendTo( ".productimage" );
});

$.getJSON( "/api/test", function( data ) {
  var items = [];
  var data = data[0];
  $.each( data, function( key, val ) {

      if (key == "price"){
          items.push( "€" + val );
      }
  });
  $( "<h2/>", {
    "class": "productprice",
    html: items.join( "" )
  }).appendTo( ".productprice" );
});

$.getJSON( "/api/test", function( data ) {
  var items = [];
  var data = data[0];
  $.each( data, function( key, val ) {
      if (key == "description" || key == "brand" || key == "volume") {
          items.push("<li class='" + key +"text"+ "'>"      + val + "</li>");
      }
  });

  $( "<ul/>", {
    "class": "productdesc",
    html: items.join( "" )
  }).appendTo( ".productdesc" );
});
