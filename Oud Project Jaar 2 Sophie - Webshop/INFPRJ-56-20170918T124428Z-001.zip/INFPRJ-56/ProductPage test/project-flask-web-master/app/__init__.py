from flask import Flask
from api import api
from auth import auth


app = Flask(__name__)

app.register_blueprint(auth, url_prefix='/auth')
app.register_blueprint(api, url_prefix='/api')

