from flask import Blueprint, jsonify
import user
from app.api import not_found

api = Blueprint('api', __name__)


@api.route('/user/<int:user_id>', methods = ['GET'])
def get_user(user_id):
    return user.get_user_by_id(user_id)


@api.route('/user', methods = ['POST'])
def post_user():
    return user.post_user()

@api.errorhandler(404)
def not_found_handler():
    return not_found()


@api.route('/test', methods=['GET'])
def testget():
    products = [
        {
        'id':1,
        'category':'Nonalcoholic',
        'title':'Cola Original 33cl',
        'version':'Original',
        'img':'<img src="http://i.imgur.com/5XVnHls.png" width="200px" height="200px">',
        'description':'This may be the most popular soda product out there. Coca Cola is well known for its sweet, refreshing taste that has quenched our thirst for nearly a century',
        'price':1.99,
        'brand':'Coca Cola',
        'color':'Red',
        'volume':'33cl'
        },
        {
        'id':1,
        'category':'Nonalcoholic',
        'title':'Cola Original 33cl',
        'version':'Original',
        'img':'<img src="http://i.imgur.com/5XVnHls.png" width="200px" height="200px">',
        'description':'This may be the most popular soda product out there. Coca Cola is well known for its sweet, refreshing taste that has quenched our thirst for nearly a century',
        'price':1.99,
        'brand':'Coca Cola',
        'color':'Red',
        'volume':'33cl'
        },
        {
        'id':1,
        'category':'Nonalcoholic',
        'title':'Cola Original 33cl',
        'version':'Original',
        'img':'<img src="http://i.imgur.com/5XVnHls.png" width="200px" height="200px">',
        'description':'This may be the most popular soda product out there. Coca Cola is well known for its sweet, refreshing taste that has quenched our thirst for nearly a century',
        'price':1.99,
        'brand':'Coca Cola',
        'color':'Red',
        'volume':'33cl'
        },
        {
        'id':1,
        'category':'Nonalcoholic',
        'title':'Cola Original 33cl',
        'version':'Original',
        'img':'<img src="http://i.imgur.com/5XVnHls.png" width="200px" height="200px">',
        'description':'This may be the most popular soda product out there. Coca Cola is well known for its sweet, refreshing taste that has quenched our thirst for nearly a century',
        'price':1.99,
        'brand':'Coca Cola',
        'color':'Red',
        'volume':'33cl'
        },
        {
        'id':1,
        'category':'Nonalcoholic',
        'title':'Cola Original 33cl',
        'version':'Original',
        'img':'<img src="http://i.imgur.com/5XVnHls.png" width="200px" height="200px">',
        'description':'This may be the most popular soda product out there. Coca Cola is well known for its sweet, refreshing taste that has quenched our thirst for nearly a century',
        'price':1.99,
        'brand':'Coca Cola',
        'color':'Red',
        'volume':'33cl'
        },
        {
        'id':2,
        'category': 'Nonalcoholic',
        'title': 'Cola Vanilla 33cl',
        'version': 'Vanilla',
        'img': '<img src="http://www.coca-colaproductfacts.com/content/dam/productfacts/us/productDetails/ProductImages/VanillCoke_12.png" width="200px" height="200px">',
        'description': 'This may be the most popular soda product out there. Coca Cola is well known for its sweet, refreshing taste that has quenched our thirst for nearly a century',
        'price': 3.99,
        'brand': 'Coca Cola',
        'color': 'Red',
        'volume': '33cl'
        }

    ]
    return jsonify(products)

