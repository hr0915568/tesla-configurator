import re
from base64 import b64encode
from os import urandom

from flask import request, abort, jsonify
from werkzeug.security import generate_password_hash

from app.api import not_found
from ..database import users, engine


def get_user_by_id(user_id):
    # check if there is a customer for this id
    user = users.select(users.c.id == user_id).execute().first()

    # if not return a 404
    if user is None:
        return not_found()

    # if there is then run it trough this crappy jsonify function
    # because i have not thought of a better way yet
    return jsonify_user(user)


def post_user():
    if not request.json:
        abort_post('request not json!')

    first_name      = require_argument('first_name')
    middle_name     = require_argument('middle_name')
    last_name       = require_argument('last_name')
    username        = require_argument('username', max_length=32)
    email           = require_argument('email', email=True)
    password        = require_argument('password')

    # check if username exists
    # check if email exists

    salt = b64encode(urandom(12))
    salted_password = salt + password
    password_hash = generate_password_hash(salted_password)

    # get the id for the new user
    command = users.insert().values(
        first_name=first_name,
        middle_name=middle_name,
        last_name=last_name,
        username=username,
        email=email,
        hashed_password=password_hash,
        password_salt=salt,
        active=1,
        blocked=0,
        is_admin=0,
    )

    res = engine.execute(command)

    user = users.select(users.c.username == username).execute().first()

    return jsonify_user(user)


def require_argument(
        argument,
        error_code=400,
        min_length=-1,
        max_length=-1,
        email=False):

    if argument not in request.json:
        abort_post("Argument: " + argument + " is required!")

    argument_string = request.json[argument]

    if min_length is not -1:
        if not argument_string > min_length:
            abort_post("Argument: " + argument + " not long enough!")

    if max_length is not -1:
        if not argument_string <= max_length:
            abort_post("Argument: " + argument + " is too long!")

    if email:
        if not re.match(r"[^@]+@[^@]+\.[^@]+", argument_string):
            abort_post("invalid email address!")

    return argument_string


def jsonify_user(user):
    user_json = {
        "id": user['id'],
        "first_name": user['first_name'],
        "middle_name": user['middle_name'],
        "last_name": user['last_name'],
        "username": user['username'],
        "email": user['email'],
        "date_of_birth": user['date_of_birth'],
        "created_on": user['created_on'],
        "active": user['active'],
        "blocked": user['blocked'],
        "is_admin": user['is_admin']
    }
    return jsonify(user_json)


def abort_post(message):
    res_message = {
        'status': 400,
        'message': message
    }
    response = jsonify(res_message)
    response.status_code = 400
    return response

