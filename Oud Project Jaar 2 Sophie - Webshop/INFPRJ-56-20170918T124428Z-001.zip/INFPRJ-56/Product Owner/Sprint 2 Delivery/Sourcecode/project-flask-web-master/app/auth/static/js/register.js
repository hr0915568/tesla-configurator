$(document).ready(function () {
	// calls the validate function on all specified input fields
	$('#register-form').validate({
		// validation rules
		rules: {
			firstName: {
				required: true
			},
			middleName: {
				required: true
			},
			lastName: {
				required: true
			},
			username: {
				required: true
			},
			email: {
				email: true,
				required: true
			},
			date: {
				date : true,
				required: true
			},
			password: {
				required: true
			},
		},
		submitHandler: function (form) { // for debugging
			alert('valid form submitted'); // for debugging
			return false; // for debugging
		}
	});
	$('#button').click(function() {
		if ($('#register-form').valid()) {
			// retrieve all fields from the static html page
			var first_name = $('#txt-first-name').val();
			var middle_name = $('#txt-middle-name').val();
			var last_name = $('#txt-last-name').val();
			var username = $('#txt-username').val();
			var email = $('#txt-email').val();
			var date = $('#option-date').val();
			var password = $('#txt-password').val();

			// make ajax call to API path /api/user
			$.ajax({
				url: '/api/user',
				contentType: "application/json",
				data: JSON.stringify({
					first_name: first_name,
					middle_name : middle_name,
					last_name : last_name,
					username : username,
					email : email,
					date : date,
					password : password
				}),
				type: 'POST',
				success: function(response){
					console.log(response);
				},
				error: function(error){
					document.write(fir)
					console.log(error);
				}
			});	
			alert('form is valid'); // for debugging
		} else {
			alert('form is not valid'); // for debugging
		}
	});	
});
