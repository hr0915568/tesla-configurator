class BadRequestError(ValueError):
    pass