from flask.globals import request

from app.api.utils.errors import BadRequestError


class JsonRequestParser:
    """Class for checking if arguments are in request.json
    and parse them if they are."""
    def __init__(self):
        self.requests = list()

    def add_argument(self, name, error='Argument error.'):
        """Add an argument to be checked."""
        self.requests.append(ArgumentRequest(name, error))

    def parse_args(self):
        """Check arguments and parse them
        or raise a BadRequestError"""
        arguments = {}
        for r in self.requests:
            if not self.validate_argument(r):
                raise BadRequestError(r.error)
            arguments[r.name] = request.json[r.name]
        return arguments

    @staticmethod
    def validate_argument(argument_request):
        """Check if an argument is apparent
        in request.json"""
        if argument_request.name not in request.json:
            return False
        return True


class ArgumentRequest:
    def __init__(self, _name, _error):
        self.name = _name
        self.error = _error

