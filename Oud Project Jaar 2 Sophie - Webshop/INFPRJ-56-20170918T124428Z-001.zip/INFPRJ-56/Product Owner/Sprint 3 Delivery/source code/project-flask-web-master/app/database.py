from sqlalchemy import create_engine, MetaData, Table
import os

# Get the database url from the environment variable at heroku
# connection_string = os.environ.get('DATABASE_URL', 3)

connection_string = '''postgres://odjbrkldqlykgl:S5RInrvuTPVrjWEb2TDUEEeBYv@ec2-54-247-189-242.eu-west-1.compute.amazonaws.com:5432/d51ssjkof82nkm'''

engine = create_engine(connection_string)
metadata = MetaData(bind=engine)

# Init Tables
users = Table('users', metadata, autoload=True)
products = Table('products', metadata, autoload=True)