
DEBUG = True

SERVER_NAME = 'proj56-flask-api.herokuapp.com'

SECRET_KEY = 'verysecret'