from flask import Flask
from api import api
from auth import auth
from products import products


app = Flask(__name__)

app.register_blueprint(auth, url_prefix='/auth')
app.register_blueprint(api, url_prefix='/api')
app.register_blueprint(products, url_prefix='/products')
