from flask import jsonify

from app.api.utils.errors import BadRequestError
from app.database import products


def get_product_by_id(product_id):
    p = products.select(products.c.id == product_id).execute().first()

    if p is None:
        raise BadRequestError("There is no product for this id!")

    return jsonify_product(p)

def get_products():
    query_result = products.select().execute()
    response = [ ]
    for product in query_result:
        response.append(product_to_object(product))
    return jsonify(response)


def products_sort(parameter, rev = False):
    product_properties = ['id', 'brand', 'title', 'version', 'price', 'color', 'volume', 'category']

    if parameter not in product_properties:
        raise BadRequestError('Sort property "' + parameter + '" not allowed!')

    query_result = products.select().execute()
    response = []
    for product in query_result:
        response.append(product_to_object(product))

    sorted_response = sorted(response, key=lambda x: x[parameter], reverse=rev)
    return jsonify(sorted_response)


def product_to_object(product):
    response = {
        'id': product['id'],
        'brand': product['brand'],
        'title': product['title'],
        'version': product['version'],
        'price': str(product['price']),
        'description': product['description'],
        'color': product['color'],
        'volume': product['volume'],
        'image': product['image'],
        'category': product['category']
    }
    return response






def jsonify_product(product):
    return jsonify(product)