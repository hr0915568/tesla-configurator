CREATE TABLE adresses (
 id SERIAL,
 country VARCHAR(255),
 postal_code VARCHAR(255),
 province VARCHAR(255),
 city VARCHAR(255),
 line_01 VARCHAR(255),
 line_02 VARCHAR(255),
 line_03 VARCHAR(255),
 line_04 VARCHAR(255)
);

ALTER TABLE adresses ADD CONSTRAINT PK_adresses PRIMARY KEY (id);


CREATE TABLE category (
 id SERIAL,
 parent_id INT,
 name VARCHAR(255)
);

ALTER TABLE category ADD CONSTRAINT PK_category PRIMARY KEY (id);


CREATE TABLE users (
 id SERIAL,
 first_name VARCHAR(255),
 middle_name VARCHAR(255),
 last_name VARCHAR(255),
 username VARCHAR(255),
 email VARCHAR(255),
 date_of_birth VARCHAR(255),
 created_on VARCHAR(255),
 active SMALLINT,
 blocked SMALLINT,
 is_admin SMALLINT,
 hashed_password VARCHAR(255),
 password_salt VARCHAR(255)
);

ALTER TABLE users ADD CONSTRAINT PK_users PRIMARY KEY (id);


CREATE TABLE orders (
 id SERIAL,
 user_id INT,
 created_on DATE,
 order_total DECIMAL(19,4)
);

ALTER TABLE orders ADD CONSTRAINT PK_orders PRIMARY KEY (id);


CREATE TABLE products (
 id SERIAL,
 brand VARCHAR(255),
 title VARCHAR(255),
 version VARCHAR(255),
 price DECIMAL(19,4),
 description VARCHAR(255),
 color VARCHAR(255),
 volume VARCHAR(255),
 image VARCHAR(255),
 category VARCHAR(255)
);

ALTER TABLE products ADD CONSTRAINT PK_products PRIMARY KEY (id);


CREATE TABLE sessions (
 user_id INT,
 expires_on CHAR(10),
 session_token CHAR(10)
);


CREATE TABLE wishlists (
 id SERIAL,
 name VARCHAR(255),
 user_id INT NOT NULL,
 private SMALLINT
);

ALTER TABLE wishlists ADD CONSTRAINT PK_wishlists PRIMARY KEY (id);


CREATE TABLE user_addresses (
 address_id INT NOT NULL,
 customer_id INT NOT NULL
);

ALTER TABLE user_addresses ADD CONSTRAINT PK_user_addresses PRIMARY KEY (address_id,customer_id);


CREATE TABLE favorites (
 user_id INT NOT NULL,
 product_id INT NOT NULL
);

ALTER TABLE favorites ADD CONSTRAINT PK_favorites PRIMARY KEY (user_id,product_id);


CREATE TABLE order_lines (
 order_id INT NOT NULL,
 product_id INT NOT NULL,
 price DECIMAL(19,4),
 quantity INT,
 extra_information VARCHAR(255)
);

ALTER TABLE order_lines ADD CONSTRAINT PK_order_lines PRIMARY KEY (order_id,product_id);


CREATE TABLE product_categories (
 category_id INT NOT NULL,
 product_id INT NOT NULL
);

ALTER TABLE product_categories ADD CONSTRAINT PK_product_categories PRIMARY KEY (category_id,product_id);


CREATE TABLE product_prices (
 product_id INT NOT NULL,
 created_on TIMESTAMP(10) NOT NULL,
 price DECIMAL(19,4)
);

ALTER TABLE product_prices ADD CONSTRAINT PK_product_prices PRIMARY KEY (product_id,created_on);


CREATE TABLE wishlist_products (
 product_id INT NOT NULL,
 wishlist_id INT NOT NULL
);

ALTER TABLE wishlist_products ADD CONSTRAINT PK_wishlist_products PRIMARY KEY (product_id,wishlist_id);


ALTER TABLE orders ADD CONSTRAINT FK_orders_0 FOREIGN KEY (user_id) REFERENCES users (id);


ALTER TABLE sessions ADD CONSTRAINT FK_sessions_0 FOREIGN KEY (user_id) REFERENCES users (id);


ALTER TABLE wishlists ADD CONSTRAINT FK_wishlists_0 FOREIGN KEY (user_id) REFERENCES users (id);


ALTER TABLE user_addresses ADD CONSTRAINT FK_user_addresses_0 FOREIGN KEY (address_id) REFERENCES adresses (id);
ALTER TABLE user_addresses ADD CONSTRAINT FK_user_addresses_1 FOREIGN KEY (customer_id) REFERENCES users (id);


ALTER TABLE favorites ADD CONSTRAINT FK_favorites_0 FOREIGN KEY (user_id) REFERENCES users (id);
ALTER TABLE favorites ADD CONSTRAINT FK_favorites_1 FOREIGN KEY (product_id) REFERENCES products (id);


ALTER TABLE order_lines ADD CONSTRAINT FK_order_lines_0 FOREIGN KEY (order_id) REFERENCES orders (id);
ALTER TABLE order_lines ADD CONSTRAINT FK_order_lines_1 FOREIGN KEY (product_id) REFERENCES products (id);


ALTER TABLE product_categories ADD CONSTRAINT FK_product_categories_0 FOREIGN KEY (category_id) REFERENCES category (id);
ALTER TABLE product_categories ADD CONSTRAINT FK_product_categories_1 FOREIGN KEY (product_id) REFERENCES products (id);


ALTER TABLE product_prices ADD CONSTRAINT FK_product_prices_0 FOREIGN KEY (product_id) REFERENCES products (id);


ALTER TABLE wishlist_products ADD CONSTRAINT FK_wishlist_products_0 FOREIGN KEY (product_id) REFERENCES products (id);
ALTER TABLE wishlist_products ADD CONSTRAINT FK_wishlist_products_1 FOREIGN KEY (wishlist_id) REFERENCES wishlists (id);


